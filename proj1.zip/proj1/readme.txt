INSTRUCTIONS:

-Due to google's slow updating speed. Especially when the sheet first starts or when you switch tabs back to the sheet.
Please do not tick checkboxes way too quickly. Tick checkboxes ONE at a time. WAIT for data to update. (It can take up to 5 seconds for data to update)
BE PATIENT IF YOU DO NOT WANT TO RISK LOSING DATA.


-HOWEVER, IF DATA WAS LOST, YOU CAN RESTORE DATA. GOOGLE HAVE A LOG FOR THE VERSION UPDATES. PRESS CTRL + ALT + SHIFT + H. 
-THROUGH THE LOG YOU CAN SEE WHAT DATA WAS PREVIOUSLY THERE. DO NOT REVERT VERSION OF THE SHEET THOUGH!!!



THANKS.



